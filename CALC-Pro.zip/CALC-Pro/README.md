# CALC Pro

Standard + scientific calculator, 2D grapher, programmer mode and unit converter as an installable, offline-capable PWA.
Stack: React 18, TypeScript, Vite, mathjs (expression parser — no `eval()`), vite-plugin-pwa, Vitest.

## Install and run (macOS)
```bash
# Node.js 18+ required (brew install node)
cd ~/Documents/Bhupesh/Projects/CALC-Pro
npm install
npm run dev        # http://localhost:5173
```

## Test / build
```bash
npm test           # Vitest: 50 unit tests (math, programmer, units)
npm run build      # type-check + production build into dist/
npm run preview    # serve dist/ at http://localhost:4173 (needed to test PWA install/offline)
```
Install: open the preview URL in Chrome/Edge and use the install icon in the address bar. Offline: load once, then go offline.

## Features
- Calculator: precedence, parentheses (auto-closed), %, !, sin/cos/tan + inverses, log/ln, powers, roots, mod, abs, Ans, DEG/RAD, memory MC/MR/M+/M−, live preview.
- Graph: up to 5 functions of x, drag to pan, wheel/buttons to zoom, hover/tap coordinate inspection, arrow keys + / - / 0.
- Programmer: 8/16/32/64-bit two's complement, BIN/OCT/DEC/HEX, AND OR XOR NAND NOR NOT << >> + − × ÷ MOD.
- Units: 11 categories (length, mass, time, area, volume, speed, pressure, energy, power, data, temperature).
- History (500 entries, localStorage): search, favorites, reuse, copy. Memory, angle mode and mode choice also persist.
- Keyboard: type in the display (paste works), Enter or = evaluates, Esc clears. Programmer: 0–9 A–F, operators, ~, Enter, Backspace, Esc.

## Numeric behaviour
IEEE-754 doubles shown to 12 significant digits (0.1+0.2 → 0.3). 1/0 → "Cannot divide by zero"; sqrt(-1), log(0), asin(2), tan(90°) → "Domain error"; results beyond ~1.8e308 (e.g. 200!) → "Overflow".
Percent: `200+10%` = 220, `200*10%` = 20, `50%` = 0.5 (the base is the number directly before the +/−).

## Known limitations
- No browser end-to-end (Playwright) tests and no component/integration tests are included yet.
- Only a single memory register. Graph has no pinch-zoom (use ＋/－ buttons or wheel).
- PWA icon is an SVG only; iOS "Add to Home Screen" needs a PNG apple-touch-icon.
