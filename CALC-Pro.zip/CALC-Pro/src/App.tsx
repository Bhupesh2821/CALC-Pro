import { useState } from 'react'
import { Calculator } from './Calculator'
import { Graph } from './Graph'
import { Programmer } from './Programmer'
import { Units } from './Units'

const TABS = { Calculator, Graph, Programmer, Units } as const
type Tab = keyof typeof TABS

export function App() {
  const [t, setT] = useState<Tab>('Calculator')
  const Page = TABS[t]
  return (
    <>
      <header>
        <h1>CALC <span>Pro</span></h1>
        <nav role="tablist" aria-label="Modes">
          {(Object.keys(TABS) as Tab[]).map(k => <button key={k} role="tab" aria-selected={t === k} onClick={() => setT(k)}>{k}</button>)}
        </nav>
      </header>
      <main role="tabpanel" aria-label={t}><Page /></main>
    </>
  )
}
