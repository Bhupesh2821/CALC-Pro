import { useMemo, useState } from 'react'
import { calculate, fmt, CalcError, type Angle } from './engine/calc'
import { copy, useStored } from './useStored'

type Item = { id: number; expr: string; res: string; fav: boolean }
const SCI: [string, string][] = [
  ['sin', 'sin('], ['cos', 'cos('], ['tan', 'tan('], ['π', 'π'], ['e', 'e'],
  ['sin⁻¹', 'asin('], ['cos⁻¹', 'acos('], ['tan⁻¹', 'atan('], ['x²', '^2'], ['xʸ', '^'],
  ['log', 'log('], ['ln', 'ln('], ['√', 'sqrt('], ['∛', 'cbrt('], ['n!', '!'],
  ['mod', ' mod '], ['|x|', 'abs('], ['1/x', '1/('], ['Ans', 'Ans'], ['M', 'M'],
]
const MAIN = ['AC', 'BS', '(', ')', '7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '−', '0', '.', '%', '+']
const ARIA: Record<string, string> = { AC: 'All clear', BS: 'Backspace', '÷': 'Divide', '×': 'Multiply', '−': 'Subtract', '+': 'Add', '=': 'Equals', '%': 'Percent', '(': 'Open parenthesis', ')': 'Close parenthesis', '.': 'Decimal point', 'x²': 'Square', 'xʸ': 'Power', '∛': 'Cube root', '√': 'Square root', 'n!': 'Factorial', '1/x': 'Reciprocal', '|x|': 'Absolute value', π: 'Pi', M: 'Memory value' }
const BS = /(asin|acos|atan|sin|cos|tan|log|ln|sqrt|cbrt|abs)\($|Ans$| mod $|.$/

export function Calculator() {
  const [expr, setExpr] = useState('')
  const [res, setRes] = useState('')
  const [err, setErr] = useState('')
  const [done, setDone] = useState(false)
  const [sci, setSci] = useStored('cp.sci', true)
  const [angle, setAngle] = useStored<Angle>('cp.angle', 'DEG')
  const [ans, setAns] = useStored('cp.ans', 0)
  const [mem, setMem] = useStored('cp.mem', 0)
  const [hist, setHist] = useStored<Item[]>('cp.hist', [])
  const [q, setQ] = useState('')
  const [favOnly, setFavOnly] = useState(false)

  const preview = useMemo(() => {
    if (!expr || done) return ''
    try { return fmt(calculate(expr, angle, ans, mem)) } catch { return '' }
  }, [expr, angle, ans, mem, done])

  const fail = (e: unknown) => setErr(e instanceof CalcError ? e.message : 'Error')

  const run = () => {
    try {
      const n = calculate(expr, angle, ans, mem), r = fmt(n)
      setRes(r); setErr(''); setAns(n); setDone(true)
      setHist(h => [{ id: Date.now() + Math.random(), expr, res: r, fav: false }, ...h].slice(0, 500))
    } catch (e) { fail(e) }
  }

  const press = (k: string) => {
    setErr('')
    if (k === 'AC') { setExpr(''); setRes(''); setDone(false) }
    else if (k === 'BS') { setExpr(s => s.replace(BS, '')); setDone(false) }
    else if (k === '=') run()
    else {
      setExpr(s => (done ? ('+−×÷^%!'.includes(k[0]) || k === ' mod ' ? res + k : k) : s + k))
      setDone(false)
    }
  }

  const memOp = (k: string) => {
    if (k === 'MC') setMem(0)
    else if (k === 'MR') press('M')
    else {
      try {
        const n = expr ? calculate(expr, angle, ans, mem) : ans
        setMem(k === 'M+' ? mem + n : mem - n); setErr('')
      } catch (e) { fail(e) }
    }
  }

  const shown = hist.filter(h => (!favOnly || h.fav) && `${h.expr} ${h.res}`.toLowerCase().includes(q.toLowerCase()))
  const cls = (k: string) => (k === '=' ? 'eq wide' : '÷×−+'.includes(k) ? 'op' : '')
  const btn = (label: string, k: string, c = '') => (
    <button key={label} className={c || cls(k)} aria-label={ARIA[label]} onClick={() => press(k)}>{label === 'BS' ? '⌫' : label}</button>
  )

  return (
    <div className="calc">
      <section className="panel" aria-label="Calculator">
        <div className="bar">
          <button aria-pressed={sci} onClick={() => setSci(!sci)}>{sci ? 'Scientific' : 'Standard'}</button>
          <button onClick={() => setAngle(angle === 'DEG' ? 'RAD' : 'DEG')} aria-label={`Angle unit ${angle}. Activate to switch`}>{angle}</button>
          <span className="mem" aria-live="polite">{mem !== 0 ? `M = ${fmt(mem)}` : ''}</span>
        </div>
        <input
          className="disp" aria-label="Expression" value={expr} placeholder="0" autoComplete="off" spellCheck={false}
          onChange={e => { setExpr(e.target.value); setDone(false); setErr('') }}
          onKeyDown={e => {
            if (e.key === 'Enter' || e.key === '=') { e.preventDefault(); run() }
            else if (e.key === 'Escape') press('AC')
          }}
        />
        <div className="out" role="status" aria-live="polite">
          {err ? <span className="err">{err}</span> : done && res ? <><b>= {res}</b><button aria-label="Copy result" onClick={() => copy(res)}>⧉</button></> : preview ? `= ${preview}` : ''}
        </div>
        <div className="memrow">{['MC', 'MR', 'M+', 'M−'].map(k => <button key={k} onClick={() => memOp(k)} aria-label={{ MC: 'Memory clear', MR: 'Memory recall', 'M+': 'Memory add', 'M−': 'Memory subtract' }[k]}>{k}</button>)}</div>
        {sci && <div className="pad c5">{SCI.map(([l, k]) => btn(l, k))}</div>}
        <div className="pad c4">{MAIN.map(k => btn(k, k))}{btn('=', '=')}</div>
      </section>

      <aside className="panel hist" aria-label="History">
        <h2>History</h2>
        <input type="search" aria-label="Search history" placeholder="Search history…" value={q} onChange={e => setQ(e.target.value)} />
        <div className="bar">
          <button aria-pressed={favOnly} onClick={() => setFavOnly(!favOnly)}>★ Favorites</button>
          <button onClick={() => setHist(hist.filter(h => h.fav))} disabled={!hist.some(h => !h.fav)}>Clear (keeps ★)</button>
        </div>
        {shown.length === 0 && <p className="mu">{hist.length ? 'No matches.' : 'Your calculations appear here.'}</p>}
        <ul>
          {shown.map(h => (
            <li key={h.id}>
              <button className="hbtn" onClick={() => { setExpr(h.expr); setRes(h.res); setDone(false); setErr('') }}><span>{h.expr}</span><b>= {h.res}</b></button>
              <button aria-pressed={h.fav} aria-label="Favorite" onClick={() => setHist(hist.map(x => (x.id === h.id ? { ...x, fav: !x.fav } : x)))}>{h.fav ? '★' : '☆'}</button>
              <button aria-label="Copy result" onClick={() => copy(h.res)}>⧉</button>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  )
}
