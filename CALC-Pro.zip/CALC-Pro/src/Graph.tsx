import { useEffect, useMemo, useRef, useState, type KeyboardEvent, type PointerEvent } from 'react'
import { compileFn, fmt } from './engine/calc'

const COLORS = ['#60a5fa', '#34d399', '#fbbf24', '#f472b6', '#a78bfa']
type View = { cx: number; cy: number; s: number }
const HOME: View = { cx: 0, cy: 0, s: 50 }
const clampS = (s: number) => Math.min(1e6, Math.max(1e-3, s))

export function Graph() {
  const [exprs, setExprs] = useState(['sin(x)', 'x^2/4-2'])
  const [v, setV] = useState(HOME)
  const [cur, setCur] = useState<number | null>(null)
  const [size, setSize] = useState({ w: 600, h: 400 })
  const cv = useRef<HTMLCanvasElement>(null)
  const box = useRef<HTMLDivElement>(null)
  const drag = useRef<{ x: number; y: number } | null>(null)

  const fns = useMemo(() => exprs.map(e => { try { return e.trim() ? compileFn(e, 'RAD') : null } catch { return undefined } }), [exprs])

  useEffect(() => {
    const el = box.current!
    const ro = new ResizeObserver(() => setSize({ w: Math.max(el.clientWidth, 50), h: Math.max(el.clientHeight, 50) }))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  useEffect(() => {
    const c = cv.current!
    const on = (e: WheelEvent) => { e.preventDefault(); const k = e.deltaY < 0 ? 1.15 : 1 / 1.15; setV(p => ({ ...p, s: clampS(p.s * k) })) }
    c.addEventListener('wheel', on, { passive: false })
    return () => c.removeEventListener('wheel', on)
  }, [])

  useEffect(() => {
    const c = cv.current!, { w, h } = size, d = window.devicePixelRatio || 1
    c.width = w * d; c.height = h * d
    const g = c.getContext('2d'); if (!g) return
    g.scale(d, d)
    const X = (x: number) => w / 2 + (x - v.cx) * v.s, Y = (y: number) => h / 2 - (y - v.cy) * v.s
    g.fillStyle = '#0b0c0f'; g.fillRect(0, 0, w, h)
    const raw = 80 / v.s, p = 10 ** Math.floor(Math.log10(raw)), step = [1, 2, 5, 10].map(m => m * p).find(s => s >= raw)!
    const lx = Math.min(Math.max(Y(0) + 12, 12), h - 4), ly = Math.min(Math.max(X(0) + 4, 4), w - 48)
    g.font = '11px system-ui'; g.lineWidth = 1
    const x0 = v.cx - w / 2 / v.s, x1 = v.cx + w / 2 / v.s, y0 = v.cy - h / 2 / v.s, y1 = v.cy + h / 2 / v.s
    for (let i = Math.ceil(x0 / step); i * step <= x1; i++) {
      const x = i * step
      g.strokeStyle = i === 0 ? '#5b6472' : '#1b1f26'; g.beginPath(); g.moveTo(X(x), 0); g.lineTo(X(x), h); g.stroke()
      if (i) { g.fillStyle = '#7d8590'; g.fillText(fmt(+x.toPrecision(10)), X(x) + 3, lx) }
    }
    for (let i = Math.ceil(y0 / step); i * step <= y1; i++) {
      const y = i * step
      g.strokeStyle = i === 0 ? '#5b6472' : '#1b1f26'; g.beginPath(); g.moveTo(0, Y(y)); g.lineTo(w, Y(y)); g.stroke()
      if (i) { g.fillStyle = '#7d8590'; g.fillText(fmt(+y.toPrecision(10)), ly, Y(y) - 3) }
    }
    fns.forEach((f, i) => {
      if (!f) return
      g.strokeStyle = COLORS[i % 5]; g.lineWidth = 2; g.beginPath()
      let pen = false, py = 0
      for (let px = 0; px <= w; px++) {
        const sy = Y(f((px - w / 2) / v.s + v.cx))
        if (!Number.isFinite(sy) || Math.abs(sy) > 1e5 || (pen && Math.abs(sy - py) > h * 1.5)) { pen = false; continue }
        if (pen) g.lineTo(px, sy); else g.moveTo(px, sy)
        pen = true; py = sy
      }
      g.stroke()
    })
    if (cur !== null) {
      g.strokeStyle = '#3b82f680'; g.lineWidth = 1; g.beginPath(); g.moveTo(X(cur), 0); g.lineTo(X(cur), h); g.stroke()
      fns.forEach((f, i) => {
        const sy = f ? Y(f(cur)) : NaN
        if (Number.isFinite(sy)) { g.fillStyle = COLORS[i % 5]; g.beginPath(); g.arc(X(cur), sy, 5, 0, 7); g.fill() }
      })
    }
  }, [fns, v, size, cur])

  const at = (e: PointerEvent) => (e.clientX - e.currentTarget.getBoundingClientRect().left - size.w / 2) / v.s + v.cx
  const down = (e: PointerEvent) => { e.currentTarget.setPointerCapture(e.pointerId); drag.current = { x: e.clientX, y: e.clientY }; setCur(at(e)) }
  const move = (e: PointerEvent) => {
    setCur(at(e))
    const d = drag.current
    if (d) { drag.current = { x: e.clientX, y: e.clientY }; setV(p => ({ ...p, cx: p.cx - (e.clientX - d.x) / p.s, cy: p.cy + (e.clientY - d.y) / p.s })) }
  }
  const zoom = (k: number) => setV(p => ({ ...p, s: clampS(p.s * k) }))
  const key = (e: KeyboardEvent) => {
    const m = 40 / v.s
    if (e.key === 'ArrowLeft') setV(p => ({ ...p, cx: p.cx - m }))
    else if (e.key === 'ArrowRight') setV(p => ({ ...p, cx: p.cx + m }))
    else if (e.key === 'ArrowUp') setV(p => ({ ...p, cy: p.cy + m }))
    else if (e.key === 'ArrowDown') setV(p => ({ ...p, cy: p.cy - m }))
    else if (e.key === '+' || e.key === '=') zoom(1.25)
    else if (e.key === '-') zoom(0.8)
    else if (e.key === '0') setV(HOME)
    else return
    e.preventDefault()
  }

  return (
    <section className="panel" aria-label="Graphing calculator">
      {exprs.map((e, i) => (
        <div className="fn" key={i}>
          <span className="sw" style={{ background: COLORS[i % 5] }} aria-hidden />
          <label className="grow">
            <span className="sr">Function {i + 1}</span>
            <input value={e} aria-label={`y = f(x) ${i + 1}`} aria-invalid={fns[i] === undefined} placeholder="e.g. sin(x)/x" onChange={ev => setExprs(exprs.map((x, j) => (j === i ? ev.target.value : x)))} />
          </label>
          {fns[i] === undefined && <span className="err">Invalid</span>}
          <button aria-label={`Remove function ${i + 1}`} onClick={() => setExprs(exprs.filter((_, j) => j !== i))}>✕</button>
        </div>
      ))}
      <div className="bar">
        <button disabled={exprs.length >= 5} onClick={() => setExprs([...exprs, ''])}>+ Function</button>
        <button onClick={() => zoom(1.25)} aria-label="Zoom in">＋</button>
        <button onClick={() => zoom(0.8)} aria-label="Zoom out">－</button>
        <button onClick={() => setV(HOME)}>Reset view</button>
      </div>
      <div className="gbox" ref={box}>
        <canvas ref={cv} tabIndex={0} role="img" aria-label="Function graph. Arrow keys pan, plus and minus zoom, 0 resets."
          onPointerDown={down} onPointerMove={move} onPointerUp={() => (drag.current = null)} onPointerCancel={() => (drag.current = null)} onKeyDown={key} />
      </div>
      <div className="out" role="status" aria-live="off">
        {cur === null ? 'Hover or tap the graph to inspect coordinates. Drag to pan; wheel or ＋/－ to zoom.' : (
          <span>x = {fmt(+cur.toPrecision(8))}{fns.map((f, i) => f ? <span key={i} style={{ color: COLORS[i % 5] }}> · y{i + 1} = {fmt(+f(cur).toPrecision(8))}</span> : null)}</span>
        )}
      </div>
    </section>
  )
}
