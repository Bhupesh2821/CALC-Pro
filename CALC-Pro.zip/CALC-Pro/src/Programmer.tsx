import { useState, type KeyboardEvent } from 'react'
import { apply, not, show, wrap, type Bits, type Op } from './engine/programmer'
import { copy } from './useStored'

const OPS: Op[] = ['AND', 'OR', 'XOR', 'NAND', 'NOR', 'MOD', '<<', '>>', '+', '-', '×', '÷']
const NAME: Record<number, string> = { 16: 'HEX', 10: 'DEC', 8: 'OCT', 2: 'BIN' }
const KEYMAP: Record<string, Op> = { '+': '+', '-': '-', '*': '×', '/': '÷', '&': 'AND', '|': 'OR', '^': 'XOR', '%': 'MOD' }

export function Programmer() {
  const [bits, setBits] = useState<Bits>(32)
  const [base, setBase] = useState(10)
  const [v, setV] = useState(0n)
  const [acc, setAcc] = useState<bigint | null>(null)
  const [op, setOp] = useState<Op | null>(null)
  const [fresh, setFresh] = useState(true)
  const [err, setErr] = useState('')
  const B = BigInt(base)

  const guard = (f: () => void) => { try { setErr(''); f() } catch (e) { setErr((e as Error).message) } }
  const digit = (d: number) => { setErr(''); setV(fresh ? wrap(BigInt(d), bits) : wrap(v * B + (v < 0n ? -BigInt(d) : BigInt(d)), bits)); setFresh(false) }
  const eq = () => guard(() => { if (op && acc !== null) { setV(apply(op, acc, v, bits)); setOp(null); setAcc(null) } setFresh(true) })
  const pick = (o: Op) => guard(() => { const a = op && acc !== null && !fresh ? apply(op, acc, v, bits) : v; setV(a); setAcc(a); setOp(o); setFresh(true) })
  const clear = () => { setV(0n); setAcc(null); setOp(null); setFresh(true); setErr('') }
  const changeBits = (b: Bits) => { setBits(b); setV(wrap(v, b)); setAcc(acc === null ? null : wrap(acc, b)) }

  const key = (e: KeyboardEvent) => {
    if (e.target instanceof HTMLElement && ['BUTTON', 'SELECT'].includes(e.target.tagName) && (e.key === 'Enter' || e.key === ' ')) return
    const k = e.key.toUpperCase(), d = parseInt(k, 16)
    if (k.length === 1 && !Number.isNaN(d) && d < base) digit(d)
    else if (k === 'ENTER' || k === '=') eq()
    else if (k === 'BACKSPACE') setV(v / B)
    else if (k === 'ESCAPE') clear()
    else if (KEYMAP[e.key]) pick(KEYMAP[e.key])
    else if (e.key === '~') setV(not(v, bits))
    else return
    e.preventDefault()
  }

  return (
    <section className="panel" tabIndex={0} onKeyDown={key} aria-label="Programmer calculator">
      <div className="bar">
        {([8, 16, 32, 64] as Bits[]).map(b => <button key={b} aria-pressed={bits === b} onClick={() => changeBits(b)}>{b}-bit</button>)}
        <span className="mem">{op && acc !== null ? `${show(acc, bits, base)} ${op}` : ''}</span>
      </div>
      {[16, 10, 8, 2].map(b => (
        <div key={b} className={'row' + (b === base ? ' on' : '')}>
          <button aria-pressed={b === base} onClick={() => setBase(b)}>{NAME[b]}</button>
          <code aria-label={`${NAME[b]} value`}>{show(v, bits, b)}</code>
          <button aria-label={`Copy ${NAME[b]}`} onClick={() => copy(show(v, bits, b))}>⧉</button>
        </div>
      ))}
      <div className="out" role="status">{err && <span className="err">{err}</span>}</div>
      <div className="pad c6">{OPS.map(o => <button key={o} className="op" onClick={() => pick(o)}>{o}</button>)}</div>
      <div className="pad c4">
        {'FEDCBA9876543210'.split('').map(c => <button key={c} disabled={parseInt(c, 16) >= base} onClick={() => digit(parseInt(c, 16))}>{c}</button>)}
      </div>
      <div className="pad c4">
        <button onClick={clear} aria-label="All clear">AC</button>
        <button onClick={() => setV(v / B)} aria-label="Backspace">⌫</button>
        <button onClick={() => setV(not(v, bits))}>NOT</button>
        <button onClick={() => setV(wrap(-v, bits))} aria-label="Negate">±</button>
        <button className="eq wide" onClick={eq} aria-label="Equals">=</button>
      </div>
      <p className="mu">Values wrap to the selected word size (two's complement). Keyboard: 0–9 A–F, + - * / &amp; | ^ % ~, Enter, Backspace, Esc.</p>
    </section>
  )
}
