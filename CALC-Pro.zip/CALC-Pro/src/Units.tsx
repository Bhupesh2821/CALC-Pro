import { useState } from 'react'
import { UNITS, convertText } from './engine/units'
import { copy } from './useStored'

export function Units() {
  const [cat, setCat] = useState('Length')
  const [from, setFrom] = useState('m')
  const [to, setTo] = useState('ft')
  const [val, setVal] = useState('1')
  const units = UNITS[cat]
  const pickCat = (c: string) => { setCat(c); setFrom(UNITS[c][0]); setTo(UNITS[c][1]) }
  const n = Number(val)
  const bad = val.trim() === '' || !Number.isFinite(n)
  let out = '', err = ''
  if (bad) err = 'Enter a valid number'
  else try { out = convertText(cat, n, from, to) } catch (e) { err = (e as Error).message }

  return (
    <section className="panel" aria-label="Unit converter">
      <label>Category
        <select value={cat} onChange={e => pickCat(e.target.value)}>{Object.keys(UNITS).map(c => <option key={c}>{c}</option>)}</select>
      </label>
      <label>Value
        <input inputMode="decimal" value={val} aria-invalid={bad} onChange={e => setVal(e.target.value)} />
      </label>
      <div className="grid2">
        <label>From<select value={from} onChange={e => setFrom(e.target.value)}>{units.map(u => <option key={u}>{u}</option>)}</select></label>
        <label>To<select value={to} onChange={e => setTo(e.target.value)}>{units.map(u => <option key={u}>{u}</option>)}</select></label>
      </div>
      <div className="bar">
        <button onClick={() => { setFrom(to); setTo(from) }} aria-label="Swap units">⇄ Swap</button>
        <button disabled={!out} onClick={() => copy(out)} aria-label="Copy result">⧉ Copy</button>
      </div>
      <div className="out" role="status" aria-live="polite">{err ? <span className="err">{err}</span> : <b>{val} {from} = {out} {to}</b>}</div>
    </section>
  )
}
