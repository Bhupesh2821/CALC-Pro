import { create, all } from 'mathjs'

const math = create(all)
export type Angle = 'DEG' | 'RAD'
export class CalcError extends Error {}

const K = Math.PI / 180
const clean = (v: number) => (Math.abs(v) < 1e-14 ? 0 : v)

/** Angle-mode-aware trig overrides, injected into the mathjs scope. */
export const trigScope = (a: Angle) => {
  const k = a === 'DEG' ? K : 1
  return {
    sin: (x: number) => clean(Math.sin(x * k)),
    cos: (x: number) => clean(Math.cos(x * k)),
    tan: (x: number) => (a === 'DEG' && Math.abs(x % 180) === 90 ? NaN : clean(Math.tan(x * k))),
    asin: (x: number) => (Math.abs(x) > 1 ? NaN : Math.asin(x) / k),
    acos: (x: number) => (Math.abs(x) > 1 ? NaN : Math.acos(x) / k),
    atan: (x: number) => Math.atan(x) / k,
  }
}

/** Translate display syntax (×, ÷, π, ln, %, …) into mathjs syntax and auto-close parentheses. */
export function prepare(raw: string): string {
  let e = raw.trim().replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/π/g, 'pi').replace(/√\(/g, 'sqrt(')
  e = e.replace(/(?<![a-z])ln\(/g, '§(').replace(/(?<![a-z])log\(/g, 'log10(').replace(/§\(/g, 'log(')
  e = e.replace(/(\d+\.?\d*)\s*([+-])\s*(\d+\.?\d*)%/g, '$1$2($1*$3/100)').replace(/(\d+\.?\d*)%/g, '($1/100)')
  const open = (e.match(/\(/g) || []).length
  const close = (e.match(/\)/g) || []).length
  if (close > open) throw new CalcError('Unbalanced parentheses')
  return e + ')'.repeat(open - close)
}

export function calculate(raw: string, angle: Angle = 'DEG', ans = 0, mem = 0): number {
  const e = prepare(raw)
  if (!e) throw new CalcError('Enter an expression')
  let r: unknown
  try {
    r = math.evaluate(e, { ...trigScope(angle), Ans: ans, M: mem })
  } catch {
    throw new CalcError('Syntax error')
  }
  if (typeof r !== 'number') throw new CalcError(math.isComplex(r) ? 'Domain error' : 'Unsupported expression')
  if (Number.isNaN(r)) throw new CalcError('Domain error')
  if (!Number.isFinite(r)) {
    if (/\/\s*0(?![\d.])/.test(e)) throw new CalcError('Cannot divide by zero')
    throw new CalcError(/log/.test(e) ? 'Domain error' : 'Overflow')
  }
  return clean(r)
}

/** 12 significant digits hides binary floating-point noise (0.1+0.2 → 0.3). */
export const fmt = (n: number) => math.format(n, { precision: 12, lowerExp: -9, upperExp: 15 })

/** Compile f(x) once for fast repeated evaluation while graphing. */
export function compileFn(raw: string, angle: Angle) {
  const node = math.compile(prepare(raw))
  const scope: Record<string, unknown> = { ...trigScope(angle), x: 0 }
  return (x: number): number => {
    scope.x = x
    try {
      const r = node.evaluate(scope)
      return typeof r === 'number' ? r : NaN
    } catch {
      return NaN
    }
  }
}
