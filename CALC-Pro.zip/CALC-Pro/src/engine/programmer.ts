export type Bits = 8 | 16 | 32 | 64
export type Op = '+' | '-' | '×' | '÷' | 'MOD' | 'AND' | 'OR' | 'XOR' | 'NAND' | 'NOR' | '<<' | '>>'

/** Signed two's-complement wrap to the chosen word size. */
export const wrap = (v: bigint, b: Bits) => BigInt.asIntN(b, v)
export const not = (v: bigint, b: Bits) => wrap(~v, b)
export const show = (v: bigint, b: Bits, base: number) =>
  base === 10 ? v.toString() : BigInt.asUintN(b, v).toString(base).toUpperCase()

export function apply(op: Op, a: bigint, c: bigint, b: Bits): bigint {
  switch (op) {
    case '+': return wrap(a + c, b)
    case '-': return wrap(a - c, b)
    case '×': return wrap(a * c, b)
    case '÷': if (c === 0n) throw new Error('Cannot divide by zero'); return wrap(a / c, b)
    case 'MOD': if (c === 0n) throw new Error('Cannot divide by zero'); return wrap(a % c, b)
    case 'AND': return wrap(a & c, b)
    case 'OR': return wrap(a | c, b)
    case 'XOR': return wrap(a ^ c, b)
    case 'NAND': return wrap(~(a & c), b)
    case 'NOR': return wrap(~(a | c), b)
    case '<<': if (c < 0n || c >= BigInt(b)) throw new Error('Shift out of range'); return wrap(a << c, b)
    case '>>': if (c < 0n || c >= BigInt(b)) throw new Error('Shift out of range'); return wrap(a >> c, b)
  }
}
