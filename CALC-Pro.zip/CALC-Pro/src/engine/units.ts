import { fmt } from './calc'

const F: Record<string, Record<string, number>> = {
  Length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, 'µm': 1e-6, nm: 1e-9, mi: 1609.344, yd: 0.9144, ft: 0.3048, in: 0.0254, nmi: 1852 },
  Mass: { kg: 1, g: 0.001, mg: 1e-6, t: 1000, lb: 0.45359237, oz: 0.028349523125, st: 6.35029318 },
  Time: { s: 1, ms: 0.001, min: 60, h: 3600, d: 86400, wk: 604800, yr: 31557600 },
  Area: { 'm²': 1, 'km²': 1e6, 'cm²': 1e-4, ha: 1e4, acre: 4046.8564224, 'ft²': 0.09290304, 'in²': 6.4516e-4, 'mi²': 2589988.110336 },
  Volume: { L: 1, mL: 0.001, 'm³': 1000, 'gal (US)': 3.785411784, 'qt (US)': 0.946352946, 'pt (US)': 0.473176473, 'cup (US)': 0.2365882365, 'fl oz (US)': 0.0295735295625, 'ft³': 28.316846592, 'in³': 0.016387064 },
  Speed: { 'm/s': 1, 'km/h': 1 / 3.6, mph: 0.44704, kn: 1852 / 3600, 'ft/s': 0.3048 },
  Pressure: { Pa: 1, kPa: 1e3, MPa: 1e6, bar: 1e5, atm: 101325, psi: 6894.757293168, mmHg: 133.322387415 },
  Energy: { J: 1, kJ: 1e3, cal: 4.184, kcal: 4184, Wh: 3600, kWh: 3.6e6, eV: 1.602176634e-19, BTU: 1055.05585262 },
  Power: { W: 1, kW: 1e3, MW: 1e6, hp: 745.69987158227 },
  Data: { B: 1, KB: 1e3, MB: 1e6, GB: 1e9, TB: 1e12, KiB: 1024, MiB: 1048576, GiB: 1073741824 },
}
export const UNITS: Record<string, string[]> = { ...Object.fromEntries(Object.entries(F).map(([k, v]) => [k, Object.keys(v)])), Temperature: ['°C', '°F', 'K'] }

export function convert(cat: string, v: number, from: string, to: string): number {
  if (cat === 'Temperature') {
    const k = from === '°C' ? v + 273.15 : from === '°F' ? ((v - 32) * 5) / 9 + 273.15 : v
    return to === '°C' ? k - 273.15 : to === '°F' ? ((k - 273.15) * 9) / 5 + 32 : k
  }
  const t = F[cat]
  if (!t || !(from in t) || !(to in t)) throw new Error('Unknown unit')
  return (v * t[from]) / t[to]
}

export const convertText = (cat: string, v: number, from: string, to: string) => {
  const r = convert(cat, v, from, to)
  if (!Number.isFinite(r)) throw new Error('Overflow')
  return fmt(r)
}
