import { useEffect, useState } from 'react'

/** useState that persists to localStorage (safe when storage is unavailable). */
export function useStored<T>(key: string, init: T) {
  const [v, setV] = useState<T>(() => {
    try { const s = localStorage.getItem(key); return s ? (JSON.parse(s) as T) : init } catch { return init }
  })
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(v)) } catch { /* storage full/blocked */ } }, [key, v])
  return [v, setV] as const
}

export const copy = (s: string) => { void navigator.clipboard?.writeText(s)?.catch(() => {}) }
